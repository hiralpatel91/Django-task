from django.shortcuts import redirect, render
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login
from .models import Add

# Create your views here.

def bloodbank(request):
    return render(request,'bloodbank.html')

def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        no = request.POST['no']
        
        usr = User(username=username, email=email)
        usr.save()
        
        usr = authenticate(username=username,email=email,no=no)
        return redirect('bloodbank')
        
    return render(request,'login.html')

def addview(request):
    if request.method == 'POST':
        name = request.POST['name']
        blood_group = request.POST['blood_group']
        phone_no = request.POST['phone_no']
        disease = request.POST['disease']
        
        adddata = Add(name=name, blood_group=blood_group, phone_no=phone_no, disease=disease)
        adddata.save()
        
        return redirect('show')
    # all_add = Add.objects.all()   
        
    return render(request,'add.html')

def showview(request):
    all_add = Add.objects.all()
    return render(request,'show.html',{'all_add':all_add})

def deleteView(request, id):
    dlt = Add.objects.get(pk=id)
    dlt.delete()

    return redirect('add')

