from django.db import models

# Create your models here.
class Add(models.Model):
     name = models.CharField(max_length=50)
     blood_group = models.CharField( max_length=50)
     phone_no= models.IntegerField((" "))
     disease = models.CharField( max_length=50)
