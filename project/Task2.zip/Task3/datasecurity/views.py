from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from django.contrib import messages

# Create your views here.

def logindata(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        
        usr = authenticate(username=username , password=password)
        
        if usr is None:
            messages.info(request,'invalid user')
            return redirect('login')
        
        login(request, usr)
        return redirect('login')
    
    
    return render(request,'login.html')

def registerview(request):
    if request.method == 'POST':
        name = request.POST['name']
        phone_no = request.POST['phone_no']
        email = request.POST['email']
        username = request.POST['username']
        password = request.POST['password']
        address = request.POST['address']
        
        usr = User(email=email , username=username)
        usr.set_password(password)
        usr.save()
        return redirect('login')
    
    return render(request,'Register.html')


def logoutdata(request):
    if request.user.is_authenticated:
        logout(request)
        return redirect('Register')
    
    return render(request,'logout.html')
